## Warmup

A warmup project for Resolution Python Week 2 in which I made a CLI for saving contacts.

